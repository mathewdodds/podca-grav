---
slug: s1
title: 'Holy smokes a series'
description: 'This series explores how this is a freaking series!'
author: 'Pierre Trudeau and his son Justin'
hslug: s1
---

