---
title: 'Celery'
body_classes: modular
role: Vegetable Director
facebook: https://www.facebook.com/user
twitter: https://www.twitter.com/user
linkedin: https://www.linkedin.com/user
---

I am celery!.  Take off, Gordie Howe likes me, eh? Yes. But they aren’t alone.